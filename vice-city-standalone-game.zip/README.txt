VICE CITY 3D OPEN WORLD — STANDALONE SINGLE-FILE GAME
=====================================================

HOW TO PLAY (ZERO SETUP, WORKS OFFLINE!)
----------------------------------------
1. Double-click "index.html" to play immediately in Chrome, Edge,
   Firefox, or Safari.
   - No local server required
   - No Python or Node.js required
   - No internet connection required (Three.js + full 3D engine are built inside!)
   - Even works if double-clicked directly without extracting first!

CONTROLS
--------
- W / A / S / D or Arrow Keys : Drive / Ride / Walk / Fly
- Mouse Move                  : Smooth 360 camera look
- SHIFT                       : Nitro Boost / Sprint
- SPACE                       : Handbrake Drift / Jump / Climb (aircraft)
- F                           : Enter / Exit Car, Motorcycle, or Aircraft
- E                           : Talk to NPCs / Interact / Enter Buildings
- 1 - 7                       : Switch Weapons (Fists, Bat, 9mm, Uzi, Shotgun, M4, RPG)
- Left Click                  : Punch / Bat Swing / Shoot / Drive-By Uzi
- R                           : Cycle 1986 FM Radio Stations
- G                           : Full Tactical Map & Fast Travel
- X                           : Call Kaufman Cabs Taxi Service
- B                           : Carnival Pier Mini-Games
- T / Y                       : Change Time of Day / Weather
- Classic Cheat Codes         : Type ASPIRINE, HESOYAM, PANZER, LEAVEMEALONE,
                                COMEFLYWITHME, SEAWAYS, BIGBANG, PCJ, SANCHEZ,
                                FAGGIO, PROFESSIONALTOOLS, NUTTERTOOLS, etc.

DEPLOY TO GITHUB + VERCEL
-------------------------
1. Push all unzipped files (including index.html and assets/) to a GitHub repo.
2. Import the repo in Vercel -> Framework Preset: Other (no build command needed) -> Deploy.
3. Open your live Vercel URL — the 3D game launches automatically!
